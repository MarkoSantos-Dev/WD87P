// Create Js file the has blank array, then push or assigned 5 elements inside the array, after you add items in the array loop and show all the elements of the array.
var arr1 = [];

arr1.push("Andro", "Aubrey", "Uy", "Soriano", "Dev");
for (i = 0; i < arr1.length; i++) {
  console.log(arr1[i]);
}
