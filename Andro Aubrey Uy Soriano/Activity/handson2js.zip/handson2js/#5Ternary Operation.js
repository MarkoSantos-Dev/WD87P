// Create Js file to program an if else statement and convert this to ternary operator.

const mp1 = 8;
const grade = mp1 <= 10 ? "Congrats" : "Sorry";

console.log(grade);
