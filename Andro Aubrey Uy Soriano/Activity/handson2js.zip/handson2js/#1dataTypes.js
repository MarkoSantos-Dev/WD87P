let num = 1;
let str = "Andro";
let state = true;
let arr = ["Andro", "Aubrey", "Uy", "Soriano"];
let nullValue = null;

console.log("Number: ", num, typeof num);
console.log("String: ", str, typeof str);
console.log("Bolean: ", state, typeof state);
console.log("Array: ", arr, typeof arr);
console.log("Null Value: ", nullValue, typeof nullValue);
