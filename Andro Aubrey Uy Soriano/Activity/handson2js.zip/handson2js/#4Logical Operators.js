// Create Js file to show different Logical Operators (&& , || , !).

const x = 10;
const z = 5;

console.log(`"&&" ${x > 9 && z > 4}`);
console.log(`"||" ${x > 9 || z < 4}`);
console.log(`"!" ${!x > 10 || z < 4}`);
