const subject = prompt("What is your facvorite subject?");
switch (subject) {
  case "Math": {
    console.log("Sabaw ka ngayon");
    break;
  }
  case "English": {
    console.log("Duguan ka ngayon boy!");
    break;
  }
  case "P.E": {
    console.log("Papaawis din haha");
    break;
  }
  case "Recess": {
    console.log("Foodtrip na");
    break;
  }
  default: {
    console.log("Walang ganyan subject wag imbento!");
  }
}
