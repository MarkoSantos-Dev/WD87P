// Create Js File to show different Assignment Operators (=, +=, -=, *=, /=, %=, **=).

let x = 10;

console.log(`"=" ${((x = 10), x)} ${typeof x}`);
console.log(`"+=" ${((x += 10), x)} ${typeof x}`);
console.log(`"-=" ${((x -= 10), x)} ${typeof x}`);
console.log(`"*=" ${((x *= 10), x)} ${typeof x}`);
console.log(`"/=" ${((x /= 10), x)} ${typeof x}`);
console.log(`"%=" ${((x %= 10), x)} ${typeof x}`);
console.log(`"**=" ${((x **= 10), x)} ${typeof x}`);
