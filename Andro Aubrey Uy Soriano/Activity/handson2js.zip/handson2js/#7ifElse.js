// Create Js file to program if, else if , else statement.

const mp1 = 100;

if (mp1 >= 10 && mp1 <= 15) {
  console.log("Congrats");
} else if (mp1 <= 9) {
  console.log("Sorry");
} else {
  console.log("Try Again");
}
