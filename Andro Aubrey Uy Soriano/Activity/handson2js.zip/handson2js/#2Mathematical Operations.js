// Create Js file to show different Mathematical Operations(+, - , *, /, **, %, ++, --).

let numx = 10;
let numz = 5;

console.log(`"Addtion" ${numx + numz}, ${typeof numx}`);
console.log(`"Subtract" ${numx - numz}, ${typeof numx}`);
console.log(`"Multiplication" ${numx * numz}, ${typeof numx}`);
console.log(`"Division" ${numx / numz}, ${typeof numx}`);
console.log(`"Increment" ${numx++}, ${typeof numx}`);
console.log(`"Decrement" ${numz--}, ${typeof numx}`);
