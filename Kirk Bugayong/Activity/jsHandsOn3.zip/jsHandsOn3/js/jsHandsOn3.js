    // submit name
function displayStudentName(){
    let inputName = document.getElementById("studentNameInput").value;
    document.getElementById("studentName").textContent = `${inputName}`;
}

let mathInput, engInput, sciInput, compInput, musicInput, artsInput, filInput, peInput;
let totalGrades = {};

    // get input
function getInput() {
    mathInput = (document.getElementById('math').value !== "") ? parseFloat(document.getElementById('math').value) : 0;
    if (isNaN(mathInput)) {
        alert('***ERROR: Invalid input!***\n\n\nNote: Grades will still be computed regardless of the input. However, for accurate computation, please enter a valid grade.');
        mathInput = 0;
    }
    totalGrades['Math'] = mathInput;
    document.getElementById('displayMathGrade').textContent = `${mathInput.toFixed(2)}%`;

    engInput = (document.getElementById('english').value !== "") ? parseFloat(document.getElementById('english').value) : 0;
    if (isNaN(engInput)) {
        alert('***ERROR: Invalid input!***\n\n\nNote: Grades will still be computed regardless of the input. However, for accurate computation, please enter a valid grade.');
        engInput = 0;
    }
    totalGrades['English'] = engInput;
    document.getElementById('displayEnglishGrade').textContent = `${engInput.toFixed(2)}%`;

    sciInput = (document.getElementById('science').value !== "") ? parseFloat(document.getElementById('science').value) : 0;
    if (isNaN(sciInput)) {
        alert('***ERROR: Invalid input!***\n\n\nNote: Grades will still be computed regardless of the input. However, for accurate computation, please enter a valid grade.');
        sciInput = 0;
    }
    totalGrades['Science'] = sciInput;
    document.getElementById('displayScienceGrade').textContent = `${sciInput.toFixed(2)}%`;

    compInput = (document.getElementById('computer').value !== "") ? parseFloat(document.getElementById('computer').value) : 0;
    if (isNaN(compInput)) {
        alert('***ERROR: Invalid input!***\n\n\nNote: Grades will still be computed regardless of the input. However, for accurate computation, please enter a valid grade.');
        compInput = 0;
    }
    totalGrades['Computer'] = compInput;
    document.getElementById('displayComputerGrade').textContent = `${compInput.toFixed(2)}%`;

    musicInput = (document.getElementById('music').value !== "") ? parseFloat(document.getElementById('music').value) : 0;
    if (isNaN(musicInput)) {
        alert('***ERROR: Invalid input!***\n\n\nNote: Grades will still be computed regardless of the input. However, for accurate computation, please enter a valid grade.');
        musicInput = 0;
    }
    totalGrades['Music'] = musicInput;
    document.getElementById('displayMusicGrade').textContent = `${musicInput.toFixed(2)}%`;

    artsInput = (document.getElementById('arts').value !== "") ? parseFloat(document.getElementById('arts').value) : 0;
    if (isNaN(artsInput)) {
        alert('***ERROR: Invalid input!***\n\n\nNote: Grades will still be computed regardless of the input. However, for accurate computation, please enter a valid grade.');
        artsInput = 0;
    }
    totalGrades['Arts'] = artsInput;
    document.getElementById('displayArtsGrade').textContent = `${artsInput.toFixed(2)}%`;

    filInput = (document.getElementById('filipino').value !== "") ? parseFloat(document.getElementById('filipino').value) : 0;
    if (isNaN(filInput)) {
        alert('***ERROR: Invalid input!***\n\n\nNote: Grades will still be computed regardless of the input. However, for accurate computation, please enter a valid grade.');
        filInput = 0;
    }
    totalGrades['Filipino'] = filInput;
    document.getElementById('displayFilipinoGrade').textContent = `${filInput.toFixed(2)}%`;

    peInput = (document.getElementById('pe').value !== "") ? parseFloat(document.getElementById('pe').value) : 0;
    if (isNaN(peInput)) {
        alert('***ERROR: Invalid input!***\n\n\nNote: Grades will still be computed regardless of the input. However, for accurate computation, please enter a valid grade.');
        peInput = 0;
    }
    totalGrades['PE'] = peInput;
    document.getElementById('displayPeGrade').textContent = `${peInput.toFixed(2)}%`;
}
    // compute pass/fail
function getPassFail(){
    getInput();

    const totalGrades = {
        Math : mathInput,
        English : engInput,
        Science : sciInput,
        Computer : compInput,
        Music : musicInput,
        Arts : artsInput,
        Filipino : filInput,
        PE : peInput
    }; 

    let failed = [];
    let passed = [];

    for (let subject in totalGrades) {
        let grade = totalGrades[subject];
        if (grade < 75) {
            failed.push(`<p><span class="failed-text">${subject}:</span> <span class="failed-grade rounded ps-1 pe-1">${grade.toFixed(2)}%</span></p>`);
        } else if (grade >= 75 && grade <= 100) {
            passed.push(`<p><span class="passed-text">${subject}:</span> <span class="passed-grade rounded ps-1 pe-1">${grade.toFixed(2)}%</span></p>`);
        }
    }

    document.getElementById("failedGrades").innerHTML = failed.join("");
    document.getElementById("passedGrades").innerHTML = passed.join("");
}

    // compute average
function getAverage (){
    getPassFail();

    let sum = 0;

    for (let subject in totalGrades){
        sum += totalGrades[subject];
    }

    const average = sum / Object.keys(totalGrades).length;

        if (average <= 100){
            document.getElementById("averageGrade").textContent = `${average.toFixed(2)}%`;
        }
        else {
            document.getElementById("averageGrade").textContent = '';
        }

        if (average > 50 && average <= 68.99){
            document.getElementById("result").textContent = "Retake";
            document.getElementById("result").style.backgroundColor = "#ef4444";
            document.getElementById("result").style.color = "#000";
        }
        else if (average >= 69 && average <=74.99){
            document.getElementById("result").textContent = "Remedial";
            document.getElementById("result").style.backgroundColor = "#eab308";
            document.getElementById("result").style.color = "#000";
        }
        else if (average >= 75 && average <=100){
            document.getElementById("result").textContent = "Passed";
            document.getElementById("result").style.backgroundColor = "#22c55e";
            document.getElementById("result").style.color = "#000";
        }
        else {
            document.getElementById("result").textContent = "Invalid";
            document.getElementById("result").style.backgroundColor = "#000";
            document.getElementById("result").style.color = "#fff";
        }
}

function mainFunction(){
    getInput();
    getPassFail();
    getAverage();
}

    // clear button
document.getElementById("clearInputs").addEventListener("click", function () {
    // clear input
    document.getElementById("studentNameInput").value = "";
    document.getElementById("math").value = "";
    document.getElementById("english").value = "";
    document.getElementById("science").value = "";
    document.getElementById("computer").value = "";
    document.getElementById("music").value = "";
    document.getElementById("arts").value = "";
    document.getElementById("filipino").value = "";
    document.getElementById("pe").value = "";
    // clear display
    document.getElementById("displayMathGrade").textContent = "";
    document.getElementById("displayEnglishGrade").textContent = "";
    document.getElementById("displayScienceGrade").textContent = "";
    document.getElementById("displayComputerGrade").textContent = "";
    document.getElementById("displayMusicGrade").textContent = "";
    document.getElementById("displayArtsGrade").textContent = "";
    document.getElementById("displayFilipinoGrade").textContent = "";
    document.getElementById("displayPeGrade").textContent = "";
    document.getElementById("averageGrade").textContent = "";
    document.getElementById("result").textContent = "";
    document.getElementById("result").style.backgroundColor = ""
    document.getElementById("failedGrades").textContent = "";
    document.getElementById("passedGrades").textContent = "";
    document.getElementById("studentName").textContent = "";
});