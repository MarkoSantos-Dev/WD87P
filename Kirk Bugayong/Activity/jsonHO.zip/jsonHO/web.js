// navbar

    // Wait for the DOM to be ready
    document.addEventListener("DOMContentLoaded", function () {
        // Select the navigation element by its class
        const navigation = document.querySelector(".navbar");
      
        // Create the navigation structure
        const ul = document.createElement("ul");
        ul.classList.add("navbar-nav", "me-auto", "mb-2", "mb-lg-0");
      
        const items = [
          { text: "Home", href: "http://animequote.rf.gd" },
          { text: "Raw", href: "raw.html" }
        ];
      
        items.forEach((item) => {
          const li = document.createElement("li");
          li.classList.add("nav-item");
      
          const a = document.createElement("a");
          a.classList.add("nav-link");
          a.href = item.href;
          a.textContent = item.text;
      
          li.appendChild(a);
          ul.appendChild(li);
        });
    
        // Add the navigation structure to the navigation element
        navigation.querySelector(".collapse").appendChild(ul);
      });

fetch("https://kirkneri.github.io/randomapi/anime.json")
  .then(response => response.json())
  .then(data => {
    const rawData = JSON.stringify(data);
    const body = document.querySelector("body");

    const bgDiv = document.createElement("div");
    bgDiv.style.backgroundImage = 'url("/img/wp12849262.jpg")';
    bgDiv.style.backgroundRepeat = "no-repeat";
    bgDiv.style.backgroundSize = "cover";
    bgDiv.style.backgroundAttachment = "fixed";
    bgDiv.style.opacity = "0.3"; 
    bgDiv.style.position = "fixed";
    bgDiv.style.top = "0";
    bgDiv.style.left = "0";
    bgDiv.style.width = "100%";
    bgDiv.style.height = "100%";
    bgDiv.style.zIndex = "-1"; 
    body.appendChild(bgDiv);

    const jsonDiv = document.createElement("div");
    jsonDiv.setAttribute("style", "word-wrap: break-word", "white-space: pre-wrap");
    jsonDiv.textContent = rawData;
    jsonDiv.style.color = "rgb(0, 0, 0)"
    jsonDiv.style.borderRadius = "15px";
    jsonDiv.style.margin = "20px"
    jsonDiv.style.padding = "8px"
    jsonDiv.style.textAlign = "justify";
    jsonDiv.style.zIndex = "1"; 
    body.appendChild(jsonDiv);
  });