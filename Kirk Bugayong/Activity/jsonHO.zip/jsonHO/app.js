// navbar

// Wait for the DOM to be ready
document.addEventListener("DOMContentLoaded", function () {
    // Select the navigation element by its class
    const navigation = document.querySelector(".navbar");
  
    // Create the navigation structure
    const ul = document.createElement("ul");
    ul.classList.add("navbar-nav", "me-auto", "mb-2", "mb-lg-0");
  
    const items = [
      { text: "Home", href: "http://animequote.rf.gd" },
      { text: "Raw", href: "raw.html" }
    ];
  
    items.forEach((item) => {
      const li = document.createElement("li");
      li.classList.add("nav-item");
  
      const a = document.createElement("a");
      a.classList.add("nav-link");
      a.href = item.href;
      a.textContent = item.text;
  
      li.appendChild(a);
      ul.appendChild(li);
    });

    // Add the navigation structure to the navigation element
    navigation.querySelector(".collapse").appendChild(ul);
  });

document.addEventListener("DOMContentLoaded", function () {
    fetch("https://kirkneri.github.io/randomapi/anime.json")
    .then(response => response.json())
    .then(data => {
      const animeData = data.data;
      const cardContainer = document.getElementById("card-container");
      cardContainer.style.marginTop = "10px";
      const body = document.querySelector("body");
    
      const bgDiv = document.createElement("div");
      bgDiv.style.backgroundImage = 'url("img/wp12849262.jpg")';
      bgDiv.style.backgroundRepeat = "no-repeat";
      bgDiv.style.backgroundSize = "cover";
      bgDiv.style.backgroundAttachment = "fixed";
      bgDiv.style.position = "fixed";
      bgDiv.style.top = "0";
      bgDiv.style.left = "0";
      bgDiv.style.width = "100%";
      bgDiv.style.height = "100%";
      bgDiv.style.zIndex = "-1";
      body.appendChild(bgDiv);

      function createCard(anime, character, quote) {
        const card = document.createElement("div");
        card.classList.add("card", "text-center", "mb-3", "font-monospace");
        card.style.backgroundColor = "rgba(255, 255, 255, .9)";
      
        const cardHeader = document.createElement("div");
        cardHeader.classList.add("card-header", "fw-bold", "fs-3", "text-danger");
        cardHeader.textContent = anime;
      
        const cardBody = document.createElement("div");
        cardBody.classList.add("card-body", "text-black");
      
        const cardTitle = document.createElement("h5");
        cardTitle.classList.add("card-title", "fw-semibold", "fs-4");
        cardTitle.textContent = character;
      
        const cardText = document.createElement("p");
        cardText.classList.add("card-text", "fst-italic", "fs-5");
        cardText.textContent = quote;
      
        cardBody.appendChild(cardTitle);
        cardBody.appendChild(cardText);
      
        card.appendChild(cardHeader);
        card.appendChild(cardBody);
      
        return card;
      }      
  
      animeData.forEach(char => {
        const card = createCard(`Show: ${char.anime}`, `${char.character}`, `"${char.quote}"`);
        cardContainer.appendChild(card);
      });
    })
    .catch(error => console.error("No data has been fetched.", error));

});
