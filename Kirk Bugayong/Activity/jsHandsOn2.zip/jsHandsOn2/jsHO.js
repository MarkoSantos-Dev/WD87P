// 1. Create a Js file that will show different Data Types(Number, String, Object). Used typeof keyword to show the data types.
// example:
// console.log("Number: ", numberVar, typeof numberVar);
// console.log("String: ", stringVar, typeof stringVar);
// console.log("Bolean: ", isTest , typeof isTest);
// console.log("Array: ", arrayOfColors , typeof arrayOfColor);
// console.log("Null Value: ", nullValue , typeof nullValue);
    let num = 69;
    let num1 = 69;
    let num2 = num;
    num--;
    let str = 'hakdog';
    let boo = 45 > 24;
    let arr = [1,2,3,4,5]
    let alaws = null;

    console.log(`Number: ${num} typeof:`,typeof(num));
    console.log(`String: ${str} typeof:`,typeof(str));
    console.log(`Boolean: ${boo} typeof:`,typeof(boo));
    console.log(`Array: ${arr} typeof:`,typeof(arr));
    console.log(`Null Value: ${alaws} typeof:`,typeof(alaws));

// 2. Create Js file to show different Mathematical Operations(+, - , *, /, **, %, ++, --).
    console.log(`Mathematical Operations (+): ${num+num1}`);
    console.log(`Mathematical Operations (-): ${num-num1}`);
    console.log(`Mathematical Operations (*): ${num*num1}`);
    console.log(`Mathematical Operations (/): ${num/num1}`);
    console.log(`Mathematical Operations (**): ${num**num1}`);
    console.log(`Mathematical Operations (%): ${num % num1}`);
    console.log(`Mathematical Operations (++): ${num2}`);
    console.log(`Mathematical Operations (--): ${num2}`);

// 3. Create Js File to show different Assignment Operators (=, +=, -=, *=, /=, %=, **=).
    let xyz = 100;
    console.log(`Assignment Operators (=): ${xyz}`);
    let asd = xyz += 200;
    console.log(`Assignment Operators (=): ${asd}`);
    let qwe = asd -= 50; 
    console.log(`Assignment Operators (=): ${qwe}`);
    let rty = qwe *= 50;
    console.log(`Assignment Operators (=): ${rty}`);
    let dfg = rty /= 50;
    console.log(`Assignment Operators (=): ${dfg}`);
    let zxc = dfg %= 3;
    console.log(`Assignment Operators (=): ${zxc}`);
    let bnm = zxc **= 3;
    console.log(`Assignment Operators (=): ${bnm}`);

// 4. Create Js file to show different Logical Operators (&& , || , !).
    let logic = 100;
    let logic1 = 200;
    let log = (logic < logic1 && logic > logic1);
    let logg = (logic == 100 || logic == 200);
    let loggg = (logic != 200);
    console.log(`AND: ${log}`);
    console.log(`OR: ${logg}`);
    console.log(`NOT: ${loggg}`);
    
// 5. Create Js file to program an if else statement and convert this to ternary operator.
    let power = 9999;
    if (power === 9999){
        console.log("You are strong!");
    }
    else {
        console.log("You are weak!");
    }

    const outcome = power === 9998 ? 'You are strong' : 'You are weak!';
    console.log(outcome);
// 6. Create Js file the has a blank array, then push or assigned 5 elements inside the array, after you add items in the array loop and show all the elements of the array.
    let array = [];
    
    array.push('Thank','God','it`s','Friday','Night');
    for (i=0; i<array.length; i++){
        console.log(`Array: [${array[i]}]`);
    }
// 7. Create Js file to program if, else if , else statement.
    let temp = parseFloat(prompt('Please enter your temperature:'))

    if (!isNaN(temp)){
        if (temp <= 37){
            console.log('Your temperature is normal.');
        }
        else if (temp > 37){
            console.log('You have a fever!');
        }
        else {
            console.log('Please enter a valid temperature.')
        }
    }

// 8. Create Js file to program switch case statement.
    let plan = prompt('Please enter your plan: (basic, pro, premium)');
    switch (plan){
        case 'basic':
            console.log('Basic is only for $0.99.');
        break;
        case 'pro':
            console.log('Pro plan is for $4.99.');
        break;
        case 'premium':
            console.log('Premium plan is for $9.99.')
        break;
        default:
            console.log('Sorry, no free plans for now.:(');
    }