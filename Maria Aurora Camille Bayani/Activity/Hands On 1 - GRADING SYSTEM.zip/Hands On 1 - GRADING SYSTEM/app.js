let score = Number(prompt('What is your score?'));
console.log(score);

if (!isNaN(score)) {
    if (score >= 90 && !(score > 100)) {
        document.getElementById('gradefinal').innerHTML = `${score} - A - Taray perfect yernnn?`;
        console.log('A');
    }
    else if (score >= 80 && score <= 89){
        document.getElementById('gradefinal').innerHTML = `${score} - B - Pwede na...`;
        console.log('B');
    }
    else if (score >= 70 && score <= 79){
        document.getElementById('gradefinal').innerHTML = `${score} - C - Kaya pa? Aral pa onti.`;
        console.log('C');
    }
    else if (score >= 60 && score <= 69){
        document.getElementById('gradefinal').innerHTML = `${score} - D - Huy kape kape. Gising!`;
        console.log('D');
    }
    else if (score == 59){
        console.log('F');
        document.getElementById("gradefinal").innerHTML = `${score} - F - Hay nakooooooo... di nag-aaral.`;
    }
    else {
        console.log('X');
        document.getElementById("gradefinal").innerHTML = `${score} - AMBOT!!!`;
    }
}
else {
    console.log('X');
    document.getElementById("gradefinal").innerHTML = `${score} - AMBOT!!!`;
}
    

