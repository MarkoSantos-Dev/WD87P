const bill =  parseFloat(prompt("What is the total bill?")) ; //3,000
const split = parseInt(prompt("How many people to split the bill?")) ; // 3 person
const tip = parseFloat(prompt("What percentage tip would you like to give? 10, 12, or 15?")); // 10% = 900

const tipPercentage = tip / 100
const billAmnt = bill * tipPercentage
const totalBill = billAmnt + bill

document.getElementById("bill").innerHTML = `PHP ${bill}`;
document.getElementById("split").innerHTML = `${split} Person`;
document.getElementById("tip").innerHTML = `${tip}%`;
document.getElementById("totalBill").innerHTML = `PHP ${ (totalBill / split).toFixed(2) }`;