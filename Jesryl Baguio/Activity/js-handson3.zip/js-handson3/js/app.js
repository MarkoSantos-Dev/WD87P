
alert("WELCOME BACK STUDENT!")

// ! STUDENT NAME
let studentName = prompt("PLEASE ENTER YOUR NAME");
document.getElementById("outputName").innerHTML = studentName;

// ! GLOBAL VARIABLE
let arts, science, english, musics, health, math, ap, pe;
let grades = [];
let total = 0;

function submitGrade() {
  
  // ! GRADE INPUTS
  arts = parseFloat(document.getElementById("arts").value);
  science = parseFloat(document.getElementById("science").value);
  english = parseFloat(document.getElementById("english").value); 
  musics = parseFloat(document.getElementById("musics").value); 
  health = parseFloat(document.getElementById("health").value); 
  math = parseFloat(document.getElementById("math").value); 
  ap = parseFloat(document.getElementById("ap").value); 
  pe = parseFloat(document.getElementById("pe").value);

  grades['arts'] = arts;
  grades['science'] = science;
  grades['english'] = english;
  grades['musics'] = musics;
  grades['health'] = health;
  grades['math'] = math;
  grades['ap'] = ap;
  grades['pe'] = pe;

  // ! GRADES RESULTS
  document.getElementById("artsGrade").innerHTML = `${arts}`;
  document.getElementById("scienceGrade").innerHTML = `${science}`;
  document.getElementById("englishGrade").innerHTML = `${english}`;
  document.getElementById("musicsGrade").innerHTML = `${musics}`;
  document.getElementById("healthGrade").innerHTML = `${health}`;
  document.getElementById("mathGrade").innerHTML = `${math}`;
  document.getElementById("apGrade").innerHTML = `${ap}`;
  document.getElementById("peGrade").innerHTML = `${pe}`;
}

// ! CLEAR DATA
function clearData () {

  document.getElementById("arts").value = "";
  document.getElementById("science").value = "";
  document.getElementById("english").value = "";
  document.getElementById("musics").value = "";
  document.getElementById("health").value = "";
  document.getElementById("math").value = "";
  document.getElementById("ap").value = "";
  document.getElementById("pe").value = "";

  document.getElementById("artsGrade").innerHTML = "";
  document.getElementById("scienceGrade").innerHTML = "";
  document.getElementById("englishGrade").innerHTML = "";
  document.getElementById("musicsGrade").innerHTML = "";
  document.getElementById("healthGrade").innerHTML = "";
  document.getElementById("mathGrade").innerHTML = "";
  document.getElementById("apGrade").innerHTML = "";
  document.getElementById("peGrade").innerHTML = "";

  document.getElementById("avgGradeResult").innerHTML = "";
  document.getElementById("passed").innerHTML = "";
  document.getElementById("failed").innerHTML = "";
}

// ! AVERAGE CONDITION
function avgGradeResult () {
  submitGrade();
  let total = [arts , science , english , musics , health , math , ap , pe] ;
  let sum = 0;
  for (const grade of total) {
    sum += grade;
  }
  let average = sum / total.length;

  if(average >= 0 && average <= 64) {
    document.getElementById("avgGradeResult").innerHTML = `${average.toFixed(1)} INVALID`;
  } 
  else if(average >= 65 && average <= 68) {
    document.getElementById("avgGradeResult").innerHTML = `${average.toFixed(1)} FAILED`;
  } 
  else if(average >= 68 && average <= 74 ) {
    document.getElementById("avgGradeResult").innerHTML = `${average.toFixed(1)} REMEDIAL`;
  }
  else if(average >= 75 && average <= 99) {
    document.getElementById("avgGradeResult").innerHTML = `${average.toFixed(1)} PASSED`;
  }
  else {
    document.getElementById("avgGradeResult").innerHTML = `${average.toFixed(1)} INVALID`;
  }

  let countFailed = 0;
  let countPassed = 0;
  for(let num of total) {
    if(num < 75) {
      countFailed++;
    } else if (num >= 75 && num <= 100) {
      countPassed++;
    }
  }
  document.getElementById("failed").innerHTML = countFailed;
  document.getElementById("passed").innerHTML = countPassed;
}
 
// ! GLOBAL CALLING
function calculateGrade () {
  submitGrade ()
  avgGradeResult ()
}

