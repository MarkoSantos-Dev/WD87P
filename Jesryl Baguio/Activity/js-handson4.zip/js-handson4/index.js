
// const anime = async () => {
//   try {
//     const res = await fetch('https://jesryl-baguio.github.io/Api-Collection/anime.json');
//     const dataCollection = await res.json(); 

//     dataCollection.data.forEach(item => {
//       const { character, quote } = item;

//       console.log (`Name: ${character}`);
//       console.log (`Quote:${quote}`);
    
//     } )
//   } catch (error) {
//     console.log('Error:', error);
//   }
// };

// anime();

const anime = async () => {
  try {
    const res = await fetch('https://jesryl-baguio.github.io/Api-Collection/anime.json'); //! API
    const dataCollection = await res.json(); //! JSON to object

    const randomIndex = Math.floor(Math.random() * dataCollection.data.length); //! random number based on data-length
    const randomItem = dataCollection.data[randomIndex]; //! random index = random output
    const { character, anime, quote } = randomItem; //! output specific key
 
    const paragraph = document.querySelector("#text"); //! DOM
    paragraph.innerHTML =  //! DOM output
    `<p class="character">${character}</p>   
     <p class="anime">${anime}</p>  
     <p class="quote"><span>"</span> ${quote} <span>"</span></p>`;

  } catch (error) {
    console.log('Error:', error); //! display if have error
  }
};

anime(); //! global call
